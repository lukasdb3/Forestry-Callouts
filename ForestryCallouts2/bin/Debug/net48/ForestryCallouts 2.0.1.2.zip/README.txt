Install Instructions
- If appliciable, remove "ForestryCallouts.dll" and "ForestryCallouts.ini" from your GTA5\Plugins\LSPDFR folder.
- Drag and Drop "CalloutInterfaceAPI", "DAGDialogueSystem.dll" and "RageNativeUI" into your main grand theft auto v directory.
- Drag and Drop "ForestryCallouts2.dll", "ForestryCallouts2.ini", and "ForestryCallouts2" folder to your GTA5\Plugins\LSPDFR. You may then from there configure 
settings in the INI file if you wish to do so.

Editing Callsign

1-LINCOLN-18
 * 1 is the division
 * LINCOLN is the unit type
 * 18 is the beat

Division can be 1-10
Unit Type can be: "ADAM", "BOY", "CHARLES", "DAVID", "EDWARD", "FRANK", "GEORGE", "HENRY", "HUNDRED", "IDA", "JOHN", "KING", "LINCOLN", 
"MARY", "NORA", "OCEAN", "OH", "PAUL", "QUEEN", "ROBERT", "SAM", "TOM", "UNION", "VICTOR", "WILLIAM", "XRAY", "YOUNG", "ZEBRA"
Beat can be: 1-24, 30, 40, 50, 60, 70, 80, 90, 100

The above can all be edited in the INI file.
If there is a callsign error callsign will default to 1-LINCOLN-18.

Notes:

- Playable Chunks are around PaletoBay, RatonCanyon, and AltruistCamp. I plan on adding more!

- If you are only playing with Forestry Callouts installed please set the distance checker to false in the ini file. If you do 
not it will result in a crash.

- Water Callouts are in Forestry Callouts 2 but purposely disabled. You may see water related callouts in Callout Interface Menu like 
"BoatPursuit". They won't start. I plan on adding them in the future.

- Forestry Callouts 2.0 has less callouts as of now then Forestry Callouts 1.6 both are availble for now untill I have
fully recoded Forestry Callouts.

Requirements:

THIS MOD REQUIRES GRAMMAR POLICE!!

This mod should be used with, but not required:
- Callout Interface
- Ultimate Backup
- Stop The Ped