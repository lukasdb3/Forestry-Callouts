Credits:

SuperPyroManic - Helping me with the code within ForestryCallouts.
Thota - Tested ForestryCallouts
PawpiDuhCawpi - Tested ForestryCallouts
xXManATeeXx - Tested ForestryCallouts
UnknownBastion - Was actually the one who came up with the name "ForestryCallouts" haha.

Installition:

In the "ForestryCallouts" download go to plugins/lspdfr drag both "ForestryCallouts.dll" and "ForestryCallouts.ini" both into
you're gta5/plugins/lpsdfr folder.

Load up the game and you should see ForestryCallouts has loaded notification when you go on duty if done correctly.

